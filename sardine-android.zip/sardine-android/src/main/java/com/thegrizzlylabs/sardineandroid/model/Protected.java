package com.thegrizzlylabs.sardineandroid.model;


import org.simpleframework.xml.Namespace;
import org.simpleframework.xml.Root;

@Root
@Namespace(prefix = "D", reference = "DAV:")
public class Protected {

	
}
