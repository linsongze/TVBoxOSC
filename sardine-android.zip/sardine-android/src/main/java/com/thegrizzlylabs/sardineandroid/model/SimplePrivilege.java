package com.thegrizzlylabs.sardineandroid.model;
//simple marker for privileges
public interface SimplePrivilege {

}
