package com.thegrizzlylabs.sardineandroid.model;

import org.w3c.dom.Element;

import java.util.List;

public interface EntityWithAnyElement {

    public List<Element> getAny();
}
